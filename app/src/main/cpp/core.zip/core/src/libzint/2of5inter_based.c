#include "../../../zint/backend/2of5inter_based.c"
