#include "../../../zint/backend/gb2312.h"
